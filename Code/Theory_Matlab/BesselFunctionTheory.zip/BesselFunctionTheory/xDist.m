%function FromWall = xDist(y,t,f)
clear;clc; close all

%% Constants
M=275;%10000*0.6; %Maximum pressure in Pa to match with max flow rate of 8 m/s at 5 Hz
rho= 1.225; %kg/m3 density of air at 15 C
Na= 6.02e23;%Avagadros number
Ma =28.97;%molar mass of air
mu= 1.81e-5; %kg/ms viscosity of air at 15 C
D=11e-6;  %m2/s Ethanol in air diffusion coefficent
ds=5e-3; %m sensor diameter
R= 0.5e-2; %m Radius of tube
Phi=0;
%% Sweeps
y=linspace(0,1,100);
freq=5;%linspace(0.1,10); %Hz
IntegratedX=[];
WomersleyNumbers=[];
for k=1:length(freq)
    f=freq(k);
    times=1/f%linspace(0,1/f,100);
    FarthestFromWall=[];
    Wo=R*sqrt(rho*2*pi*f/mu)
    WomersleyNumbers=[WomersleyNumbers Wo];
for j=1:length(times)
    t=times(j);


%% Velocity using equation 17 in Womersley paper

h0=M0(y.*Wo)./M0(Wo); %Dimless number
delta0=Theta0(Wo)-Theta0(y.*Wo); %degrees
eta0=atan2(h0.*sin(delta0*pi/180),1-h0.*cos(delta0*pi/180)); %# between -pi and pi
Mprime=sqrt(1+h0.^2-2.*h0.*cos(delta0*pi/180));


w=(M./mu).*(R.^2./Wo.^2).*Mprime.*sin(2.*pi.*f.*t + Phi + eta0); %f*t = number of cycles so if t=1/f then should be one cycle
x=sqrt(2.*D.*ds./abs(w)); %include abs value because vel could be either direction
FromWall=x./R;
%plot(y,w)
xlabel('Center to edge of tube ->')
ylabel('velocity (m/s)')
%figure
plot(y,FromWall); %TURN THIS ON TO GET GRAPH OF TRAVEL DISTANCE DIMLESS RADIUS
xlabel('Center to edge of tube ->')
ylabel('x/R distance molecule can travel')
hold on

CapturedLogic=FromWall>1-y;%If the distance a molecule can travel is less than the distance needed to reach the wall
%start from end and go back until hit a zero
for i=2:length(CapturedLogic)-2
    if CapturedLogic(end-i-1) && CapturedLogic(end-i) %if it is true at this position and the one before it
        %do nothing
    else
        CapturedLogic(end - (i+1))=0; %Any molecules after the first 0 will not be able to pass
    end
end
CapturedYValues=y(CapturedLogic);
CapturedFromWallValues=FromWall(CapturedLogic);
plot(CapturedYValues,CapturedFromWallValues,'x'); %MAKE SURE PLOT(Y,FROMWALL) IS ON!

hold on
FarthestFromWall=[FarthestFromWall 1-min(CapturedFromWallValues)];


end

% XFarthestFromWall=1-FarthestFromWall;
% IntegratedX=[IntegratedX trapz(times,XFarthestFromWall)];
% VolumePossibleToCollectPerCycle=IntegratedX.*R.*ds.^2./4;%possible volume of molecules available to collect 
% NoverCPossibleToCollectPerCycle=VolumePossibleToCollectPerCycle.*rho.*Na./Ma; %possible air molecules landing
% plot(times,XFarthestFromWall)
% xlabel('time (s)')
% hold on
end
%figure
% plot(WomersleyNumbers, NoverCPossibleToCollectPerCycle)
% xlabel('Wo')
% ylabel('Npossible')

%% Plot total after 10 seconds
% figure
% CyclesTotalIn10Sec=1.*freq;
% NoverCPossibleToCollectTotal=NPossibleToCollectPerCycle.*CyclesTotalIn10Sec;
% % % plot(WomersleyNumbers,NoverCPossibleToCollectTotal)
% xlabel('Wo')
% ylabel('Npossible After 10 Seconds')
%end 