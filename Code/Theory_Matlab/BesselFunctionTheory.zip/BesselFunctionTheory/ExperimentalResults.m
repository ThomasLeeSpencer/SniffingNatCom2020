close all
clc

Wo=[3.593139956
3.28007301
2.933786489
2.454581881]'; %input Womersley number for experiments

C= [0.0889
0.04445
0.00889]'; %input Concentration for experiments

A= [0.332472797 0.502342583 0.44706898 0.69720351 
    0.108318816 0.297649062 0.34442557 0.54337782 
    0.057158014 0.070808068 0.138192819 0.155078949] ; %output Amplitudes for experiments


figure
surf(Wo,C,A)
xlabel('Wo')
ylabel('C')
zlabel('A')
