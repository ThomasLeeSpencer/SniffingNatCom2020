clear; close all; clc

%% Goal
%Find "MaxX" distance from center of channel where the particles in the
% stream can reach the walls in time before the velocity takes it past the
% sensor
%% Independent variables to change each time
frequencies=[1]%linspace(0.5,9);%[0.5 3 9];
MinTime=0; %starting time
cycles=1; %Number of full waveforms
NumberOfTimes=200; %number of divisions of times for per cycle
Phi=0; %initial phase

%% Constants
M=275;%10000*0.6; %Maximum pressure in Pa to match with max flow rate of 8 m/s at 5 Hz
rho= 1.225; %kg/m3 density of air at 15 C
mu= 1.81e-5; %kg/ms viscosity of air at 15 C
D=11e-6;  %m2/s Ethanol in air diffusion coefficent
ds=5e-3; %m sensor diameter
R= 0.5e-2; %m Radius of tube

%% Main
%initialize
Wos=[];
MaxX=[];

for j=1:length(frequencies)
f= frequencies(j);%5%0.14;  %Hz - Frequency of oscillations
Wo=R*sqrt(rho*2*pi*f/mu);
times=linspace(MinTime,cycles*1/(f),NumberOfTimes*cycles);% input, but for different frequencies the phase will be off
y=linspace(0,1,1000);
%% Guess for r
% r=R-sqrt(2.*D.*ds./((-M./rho).*(1/(2*pi*f)).*(M0(Wo.*rinit./R)./M0(Wo)).*sind(-Theta0(Wo)+Theta0(Wo.*rinit./R))));

%% Initial velocity attempt
% 
% for i= 1:length(times)
% t=times(i);
% U=(M/rho)*(1/(2*pi*f))*(sind(2*pi*f*t+Phi)-(M0(y.*Wo)./M0(Wo)).*sind(2*pi*f*t+Phi-Theta0(Wo)+Theta0(y.*Wo)));
% plot(U,y)
% hold on
% end

%% Velocity using equation 17 in Womersley paper
h0=M0(y.*Wo)./M0(Wo); %Dimless number
delta0=Theta0(Wo)-Theta0(y.*Wo); %degrees
eta0=atan2(h0.*sin(delta0*pi/180),1-h0.*cos(delta0*pi/180)); %# between -pi and pi
Mprime=sqrt(1+h0.^2-2.*h0.*cos(delta0*pi/180));



for i= 1:length(times)
    t=times(i);
w=(M./mu).*(R.^2./Wo.^2).*Mprime.*sin(2.*pi.*f.*t + Phi + eta0); %f*t = number of cycles so if t=1/f then should be one cycle
x=sqrt(2.*D.*ds./abs(w)); %include abs value because vel could be either direction
%% plot
subplot(length(frequencies),2,2*j-1)
plot(w,y)
title(['Wo = ' num2str(Wo)])
xlabel('Velocity (m/s)')
ylabel('r/R')
axis([-8 8 0 1])
hold on
subplot(length(frequencies),2,2*j)

plot(x./R,y)
title(['Wo = ' num2str(Wo)])
hold on
plot(x./R,1-x./R)
ylabel('r/R')
xlabel('(Diffusion Distance "x")/R')
axis([0 0.1 0 1])
hold on
%% calculate intersection
intersect=y(round(y,2)==round(1-x./R,2));
if length(intersect)==1 %if there is only one value where the 1-X/r line crosses
if intersect>0 %if it is not a real number then skip it
MaxX=[MaxX 1-intersect(1)];

else
    MaxX=[MaxX 0];
end
else
    MaxX=[MaxX 0]; %skip values with multiple 
end
Wos=[Wos Wo];
end
end

Wos(MaxX==0)=[];%delete the entries where no intersection was found
times(MaxX==0)=[]; %delete the entries where no intersection was found
MaxX(MaxX==0)=[];%delete the entries where no intersection was found

figure
plot(Wos,MaxX)
ylabel('Max Diffusion Distance From Wall (1-r/R)')
xlabel('Wo')
axis([0 10 0 0.1])
figure
plot(times,MaxX)
ylabel('Max Diffusion Distance From Wall (1-r/R)')
xlabel('% of cycle')

