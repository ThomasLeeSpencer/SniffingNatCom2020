function Theta0= Theta0(z)
ber=1-((0.5.*z).^4)/(factorial(2).^2)+((0.5.*z).^8)/(factorial(4).^2)-((0.5.*z).^12)/(factorial(6).^2)+((0.5.*z).^16)/(factorial(8).^2)-((0.5.*z).^20)/(factorial(10).^2);
bei=((0.5.*z).^2)/(factorial(1).^2)-((0.5.*z).^6)/(factorial(3).^2)+((0.5.*z).^10)/(factorial(5).^2)-((0.5.*z).^14)/(factorial(7).^2)+((0.5.*z).^18)/(factorial(9).^2)-((0.5.*z).^22)/(factorial(11).^2);
Theta0=atan2(bei,ber).*180/pi; %inverse tangent in degrees
for i= 1:length(z)
    if z(i)>9 && 0< Theta0(i) < 300 %if value should be over 360 degrees now
    Theta0(i)=Theta0(i)+360;
    end  
    
    if Theta0(i) < 0
    Theta0(i)=abs(180+Theta0(i))+180; %if value is between pi and 2 pi add 180 deg 
    end
end