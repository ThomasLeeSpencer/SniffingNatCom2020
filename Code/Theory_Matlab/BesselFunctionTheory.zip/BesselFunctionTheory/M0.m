function M0 = M0(z)
ber=1-((0.5.*z).^4)/(factorial(2).^2)+((0.5.*z).^8)/(factorial(4).^2)-((0.5.*z).^12)/(factorial(6).^2)+((0.5.*z).^16)/(factorial(8).^2)-((0.5.*z).^20)/(factorial(10).^2);
bei=((0.5.*z).^2)/(factorial(1).^2)-((0.5.*z).^6)/(factorial(3).^2)+((0.5.*z).^10)/(factorial(5).^2)-((0.5.*z).^14)/(factorial(7).^2)+((0.5.*z).^18)/(factorial(9).^2)-((0.5.*z).^22)/(factorial(11).^2);
M0=sqrt(ber.^2+bei.^2);
end