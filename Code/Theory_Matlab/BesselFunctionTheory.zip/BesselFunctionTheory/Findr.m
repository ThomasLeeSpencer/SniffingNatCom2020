function r = xDist(y,t,f)
%% Constants
M=275;%10000*0.6; %Maximum pressure in Pa to match with max flow rate of 8 m/s at 5 Hz
rho= 1.225; %kg/m3 density of air at 15 C
mu= 1.81e-5; %kg/ms viscosity of air at 15 C
D=11e-6;  %m2/s Ethanol in air diffusion coefficent
ds=5e-3; %m sensor diameter
R= 0.5e-2; %m Radius of tube

%% Velocity using equation 17 in Womersley paper
Wo=R*sqrt(rho*2*pi*f/mu);
h0=M0(y.*Wo)./M0(Wo); %Dimless number
delta0=Theta0(Wo)-Theta0(y.*Wo); %degrees
eta0=atan2(h0.*sin(delta0*pi/180),1-h0.*cos(delta0*pi/180)); %# between -pi and pi
Mprime=sqrt(1+h0.^2-2.*h0.*cos(delta0*pi/180));

for i= 1:length(times)
w=(M./mu).*(R.^2./Wo.^2).*Mprime.*sin(2.*pi.*f.*t + Phi + eta0); %f*t = number of cycles so if t=1/f then should be one cycle
x=sqrt(2.*D.*ds./abs(w)); %include abs value because vel could be either direction
end
end