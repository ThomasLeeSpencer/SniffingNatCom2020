% This script shows how to generate masks outside of Matlab. Just run it.
clear all;
close all;
clc;
disp('This example creates a series of masks outside PIVlab.')
disp('It teaches you how you can create your own masks, independent of PIVlab.')
fig=figure;
set(fig,'Name','Select your mask. Double click exits and loads next image.')
for i=1:3
    A=imread(['Examples\PIVlab_Karman_' sprintf('%0.2d',i) '.bmp']);
    [junk,xmask_temp,ymask_temp]=roipoly(A);
    xmask(1:size(xmask_temp,1),i)=xmask_temp;
    ymask(1:size(ymask_temp,1),i)=ymask_temp;
end
close(fig)
clearvars -except xmask ymask
save external_mask_test.mat
disp('Start a new session in PIVlab, and load the images ')
disp('PIVlab_Karman_01.bmp until PIVlab_Karman_04.bmp')
disp('Select sequencing style 1-2, 2-3, 3-4')
disp('To apply the masks, you can now click ''Load external masks''.')
