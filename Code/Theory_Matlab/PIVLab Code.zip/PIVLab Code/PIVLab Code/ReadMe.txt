Start MATLAB and run PIVlab_GUI.m
If you run into problems, check if you have installed the required toolboxes!