close all

%% Read in Video
obj = VideoReader('2.3 Hz Bottom 15 FPS Converted.mp4') % Insert name of file here. Should be a .mp4

%% Find Number of Frames
% numFrames = 0;
%     for f = 1:2000 
%         readFrame(obj);
%         numFrames = numFrames + 1;
%     end
% Make f go from 1 to high number. Code will error, but variable numFrames
% will display the correct number of frames.

% Comment this section out when numFrames is found

%% Convert all frames to Greyscale
for k = 1 : 250%numFrames  % Reads for all frames
  this_frame = readFrame(obj);
  G = rgb2gray(this_frame); % Converts frame to greyscale
  imname = sprintf('G%d.jpeg',k); % Renames greyscale image
  imwrite(G,imname)
end

